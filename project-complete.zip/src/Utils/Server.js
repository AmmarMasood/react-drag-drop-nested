export const server = "http://localhost:5000";
